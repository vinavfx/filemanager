//------------------------------------------------------------------------------
// Copyright (c) 2004-2019 Darby Johnston
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions, and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
//   this list of conditions, and the following disclaimer in the documentation
//   and/or other materials provided with the distribution.
// * Neither the names of the copyright holders nor the names of any
//   contributors may be used to endorse or promote products derived from this
//   software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//------------------------------------------------------------------------------

namespace djv
{
    namespace Core
    {
        inline void FileIO::get8(qint8 * in, quint64 size)
        {
            return get(in, size, 1);
        }

        inline void FileIO::getU8(quint8 * in, quint64 size)
        {
            return get(in, size, 1);
        }

        inline void FileIO::get16(qint16 * in, quint64 size)
        {
            return get(in, size, 2);
        }

        inline void FileIO::getU16(quint16 * in, quint64 size)
        {
            return get(in, size, 2);
        }

        inline void FileIO::get32(qint32 * in, quint64 size)
        {
            return get(in, size, 4);
        }

        inline void FileIO::getU32(quint32 * in, quint64 size)
        {
            return get(in, size, 4);
        }

        inline void FileIO::getF32(float * in, quint64 size)
        {
            return get(in, size, 4);
        }

        inline void FileIO::set8(const qint8 * in, quint64 size)
        {
            set(in, size, 1);
        }

        inline void FileIO::setU8(const quint8 * in, quint64 size)
        {
            set(in, size, 1);
        }

        inline void FileIO::set16(const qint16 * in, quint64 size)
        {
            set(in, size, 2);
        }

        inline void FileIO::setU16(const quint16 * in, quint64 size)
        {
            set(in, size, 2);
        }

        inline void FileIO::set32(const qint32 * in, quint64 size)
        {
            return set(in, size, 4);
        }

        inline void FileIO::setU32(const quint32 * in, quint64 size)
        {
            return set(in, size, 4);
        }

        inline void FileIO::setF32(const float * in, quint64 size)
        {
            set(in, size, 4);
        }

        inline void FileIO::set8(const qint8 & in)
        {
            set8(&in, 1);
        }

        inline void FileIO::setU8(const quint8 & in)
        {
            setU8(&in, 1);
        }

        inline void FileIO::set16(const qint16 & in)
        {
            set16(&in, 1);
        }

        inline void FileIO::setU16(const quint16 & in)
        {
            setU16(&in, 1);
        }

        inline void FileIO::set32(const qint32 & in)
        {
            set32(&in, 1);
        }

        inline void FileIO::setU32(const quint32 & in)
        {
            setU32(&in, 1);
        }

        inline void FileIO::setF32(const float & in)
        {
            setF32(&in, 1);
        }

        inline void FileIO::set(const std::string & value)
        {
            set8(reinterpret_cast<const int8_t *>(value.c_str()), value.size());
        }

    } // namespace Core
} // namespace djv
