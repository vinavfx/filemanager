//------------------------------------------------------------------------------
// Copyright (c) 2004-2019 Darby Johnston
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions, and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
//   this list of conditions, and the following disclaimer in the documentation
//   and/or other materials provided with the distribution.
// * Neither the names of the copyright holders nor the names of any
//   contributors may be used to endorse or promote products derived from this
//   software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//------------------------------------------------------------------------------

#pragma once

#include <IO.h>

#include <djvUI/UIContext.h>

#include <QAction>
#include <QMap>

#include <future>

namespace djv
{
    namespace AudioExperiment2
    {
        class PlaybackSystem;

        class Context : public UI::UIContext
        {
            Q_OBJECT

        public:
            Context(int & argc, char ** argv, QObject * parent = nullptr);
            ~Context() override;

            std::shared_ptr<Util::AVQueue> ioQueue() const;
            QPointer<PlaybackSystem> playbackSystem() const;
            const QMap<QString, QPointer<QAction> > & actions() const;

        protected:
            void timerEvent(QTimerEvent *) override;

        private:
            std::shared_ptr<Util::AVQueue> _ioQueue;
            QScopedPointer<IO> _io;
            std::future<IOInfo> _ioInfoFuture;
            int _ioInfoTimer = 0;
            QScopedPointer<PlaybackSystem> _playbackSystem;
            QMap<QString, QPointer<QAction> > _actions;
        };

    } // namespace AudioExperiment2
} // namespace djv
