
//------------------------------------------------------------------------------
// Copyright (c) 2004-2019 Darby Johnston
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions, and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright notice,
//   this list of conditions, and the following disclaimer in the documentation
//   and/or other materials provided with the distribution.
// * Neither the names of the copyright holders nor the names of any
//   contributors may be used to endorse or promote products derived from this
//   software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
// AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
// IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
// ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE
// LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
// CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
// SUBSTITUE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
// INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
// CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
// ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
// POSSIBILITY OF SUCH DAMAGE.
//------------------------------------------------------------------------------

#pragma once

#include <Util.h>

#include <djvUI/ToolButton.h>

#include <QPointer>
#include <QWidget>

class QLabel;

namespace djv
{
    namespace AudioExperiment2
    {
        class Context;
        class TimelineSlider;

        class TimelineWidget : public QWidget
        {
            Q_OBJECT

        public:
            TimelineWidget(const QPointer<Context> &, QWidget * parent = nullptr);
            ~TimelineWidget() override;

        public Q_SLOTS:
            void setDuration(int64_t);
            void setCurrentTime(int64_t);
            void setPlayback(Util::PLAYBACK);

        Q_SIGNALS:
            void durationChanged(int64_t);
            void currentTimeChanged(int64_t);
            void playbackChanged(Util::PLAYBACK);

        private Q_SLOTS:
            void widgetUpdate();

        private:
            QPointer<Context> _context;
            int64_t _duration = 0;
            int64_t _currentTime = 0;
            Util::PLAYBACK _playback = Util::PLAYBACK_STOP;
            QPointer<UI::ToolButton> _stopButton;
            QPointer<UI::ToolButton> _forwardButton;
            QPointer<TimelineSlider> _slider;
            QPointer<QLabel> _timeLabel;
        };

    } // namespace AudioExperiment2
} // namespace djv
